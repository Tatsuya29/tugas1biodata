<html>
	<head>
		<title>Profile</title>
		<link rel="stylesheet" href="style.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
		<link href='https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/3.6.95/css/materialdesignicons.css'>
	</head>
	<body>
		<div class="page-content page-container" id="page-content">
		    <div class="padding">
		        <div class="row container d-flex justify-content-center">
		            <div class="col-xl-6 col-md-12">
		                <div class="card user-card-full">
		                    <div class="row m-l-0 m-r-0">
		                        <div class="col-sm-4 bg-c-lite-green user-profile">
		                            <div class="card-block text-center text-white">
		                                <div class="m-b-25"> <img src="profile.png" class="img-radius" alt="User-Profile-Image" width="100%"> </div>
		                                <h6 class="f-w-600">Muhamad Afril rohmansyah putra</h6>
		                                <p>19515005</p> <i class=" mdi mdi-square-edit-outline feather icon-edit m-t-10 f-16"></i>
		                            </div>
		                        </div>
		                        <div class="col-sm-8">
		                            <div class="card-block">
		                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600">Information</h6>
		                                <div class="row">
		                                    <div class="col-sm-6">
		                                        <p class="m-b-10 f-w-600">Email</p>
		                                        <h6 class="text-muted f-w-400">rammagantonk29@gmail.com</h6>
		                                    </div>
		                                    <div class="col-sm-6">
		                                        <p class="m-b-10 f-w-600">Phone</p>
		                                        <h6 class="text-muted f-w-400">081281481932</h6>
		                                    </div>
		                                </div>
		                                <h6 class="m-b-20 m-t-40 p-b-5 b-b-default f-w-600">My Campus</h6>
		                                <div class="row">
		                                    <img src="logo.png" class="img-radius" alt="User-Profile-Image" width="100%">
		                                </div>
		                                <ul class="social-link list-unstyled m-t-40 m-b-10">
		                                    <li><a href="#!" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="facebook" data-abc="true"><i class="mdi mdi-facebook feather icon-facebook facebook" aria-hidden="true"></i></a></li>
		                                    <li><a href="#!" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="twitter" data-abc="true"><i class="mdi mdi-twitter feather icon-twitter twitter" aria-hidden="true"></i></a></li>
		                                    <li><a href="#!" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="instagram" data-abc="true"><i class="mdi mdi-instagram feather icon-instagram instagram" aria-hidden="true"></i></a></li>
		                                </ul>
		                            </div>
		                        </div>
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	</body>
</html>